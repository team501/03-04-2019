import React, { Component } from 'react';

import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import { Link } from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Assigned from './ChuteStatus/Assigned';
import AssignedPer from './ChuteStatus/AssignedPer';
import NotAssigned from './ChuteStatus/NotAssigned';
import Legends from './ChuteStatus/Legends';
import {Doughnut} from 'react-chartjs-2';
import DonutChart from 'Components/DonutChart/DonutChart';
// import DonutChart from 'react-donut-chart';

import './ChuteStatus/land.css';
import './ChuteStatus/label.css';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

//json
import json from '../../assets/data/jsonDataConfig/Sorter/DoughnutChartConfig';

import {baseURL} from '../../services/Config';
import DonutConfig from '../../assets/data/jsonDataConfig/UnitSorterMainDashboard/Sorter/chuteDonutConfig.json';
import axios from 'axios';

const mainGrid = {
    padding: '15px',
    height: '280px',
};


class ChuteStatusOverview extends Component {
    constructor(props) {
		super(props);
		this.state = {  data: [],
						label: ['Full', 'Empty', 'Error', 'Disabled'],
					    isLoading:true
					  };
	}
	
    /*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}
	
	getRecentOrders() {
		axios.get(baseURL+'chutesummary/'+ localStorage.getItem("user_id") +this.props.sorterRoute) 
		.then(res => {
		
			const { isColorBlind } = this.props;
			var backgroundColors = json.backgroundColors
			
			//Check For color blind and change the color
			if(isColorBlind){			
				backgroundColors = json.backgroundColorsCB
			}
		
			let chuteData = {  labels: this.state.label,
						  	   datasets: [{ data: [res.data.chuteFull, res.data.empty,
							  				  	   res.data.error, res.data.disabled],
							  				backgroundColor: backgroundColors,
							  				hoverBackgroundColor: backgroundColors
									}]
					   };
			this.setState({ data: res.data, chuteData:chuteData}); 
		}).catch(function (error) {
			console.log(error);
		});
	}
    
    render () {
	
			var colors = DonutConfig.colors
			const { isColorBlind } = this.props;
			const colorsCB = ["#87871f", "#828275", "#f8e71c", "#5f5fb3"]
			
			if(isColorBlind){
				colors = colorsCB
			}
			
			
            return(
				<div>
                <RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Chute Status"}
				fullBlock
				>
                    <Grid style={mainGrid} container>	
                        <Grid item xs={11} sm={11}>
							<DonutChart 
								colors= {colors}
								innerRadius={DonutConfig.innerRadius}
								legend={DonutConfig.legend}
								clickToggle={DonutConfig.clickToggle}
								startAngle={DonutConfig.startAngle}
								toggledOffset={DonutConfig.toggledOffset}
								selectedOffset= {DonutConfig.selectedOffset}
								totalLabel={DonutConfig.totalLabel}
								colorBlindness={isColorBlind}
								data={[{
										label: 'Full',
										percent: 62,
										value:300
									},
									{
										label: 'Empty',
										percent: 31,
										value:150
									},
									{
										label: 'Error',
										percent: 5,
										value:25
									},
									{
										label: 'Disabled',
										percent: 2,
										value:5
									}
								]}

							/>
							{/* <Doughnut 
								data={this.state.chuteData} 
								height={250} 
								width={300} 
							  	options={ 
									{
										maintainAspectRatio: false, 
										responsive: false,
						  		  		legend: { display: false }
									} 
								} 
							/>   */}
                        </Grid>
                       
						<div className="right-arrow-chute col-sm-1 col-md-1 col-lg-1" >
                            <Link to={{ pathname: '/app/dashboard/chuteStatus', state: { nextLink: this.props.nextLink } }}>
                                &#x203A;
                            </Link>
                        </div>
                    </Grid>
                    
                    <Grid className="chute-bottom-grid" container>
                        <Grid item xs={4} sm={4}>
                            <Assigned value={this.state.data.assigned}/>
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <NotAssigned value={this.state.data.notassigned} />
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <AssignedPer value={this.state.data.assignedPercentage} />
                        </Grid>
                    </Grid>
            					 

                </RctCollapsibleCard>
				</div>
            );
    }
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};

export default withRouter(connect(mapStateToProps)(ChuteStatusOverview));