import React, { Component } from 'react';
import PropTypes from 'prop-types';
import * as d3 from 'd3';

/*
* Class or Component for creating individual Segments
*/
class SpeedoMeterSegment extends Component {
    static propTypes = {
        width: PropTypes.number,
        height: PropTypes.number,
        innerRadius: PropTypes.number,
        outerRadius: PropTypes.number,
        startAngle: PropTypes.number,
        endAngle: PropTypes.number,
        transform: PropTypes.string
    };

    render() {

        const arc = d3.arc()
            .innerRadius(this.props.innerRadius)
            .outerRadius(this.props.outerRadius)
            .startAngle(this.props.startAngle)
            .endAngle(this.props.endAngle);

        return (
            <g transform={this.props.transform}>
                <path d={arc()} {...this.props}/>
            </g>
        );
    }
}

/*
* Class or Component for displaying Complete Speedometer
*/
class SpeedoMeterGuage extends Component {
    static propTypes = {
        guageData: PropTypes.object, //Complete Guage Congiguration 
        width: PropTypes.number,//Speedometer width
        height: PropTypes.number,//Speedometer Height
        percent: PropTypes.number,// Current Percentage value 
        barWidth: PropTypes.number,//Bar Width Range from be 0 - 50
        needleLength: PropTypes.number,// Needle Length Range from 0 - 100
        needleRadius: PropTypes.number,//Needle Radius Range from 0 - 10
        segments: PropTypes.number,//segments number Range from 0 - 10
        needleColor: PropTypes.string,//Needle Color can be hex vlaue or name of color
        textSize: PropTypes.string, //Percentage Text Size 
        segmentColors: PropTypes.array, //Sections Configuration 
        segmentPercentage: PropTypes.array, //Sections Configuration 
		blindColors: PropTypes.array //For Color Blind config
    };

    percentToDeg = (perc) => {
        return perc * 360;
    };

    percentToRad = (perc) => {
        return this.degToRad(this.percentToDeg(perc));
    };

    degToRad = (deg) => {
        return deg * Math.PI / 180;
    };

    renderSections = () => {
        // initialize the sections array for number of segments
        let sections = [];
        const segmentsParams = this.props.segments ? this.props.segments : this.props.sections.length;
        const PercentSum = this.props.segmentPercentage.reduce((partial_sum, a) => partial_sum + a);
        const { colorBlindness } = this.props; 
        /*
        *Add validation for total segments percentage of and segments length.
        * If validation fails fetch default props for number of section/segments, segment colors and segment percentages 
        */
        if(PercentSum == 100 && this.props.segmentPercentage.length == this.props.segments) {
            for(let i=0; i < this.props.segments; i++){
                let sectioColorParam;
                sectioColorParam = colorBlindness ? this.props.blindColors[i % this.props.blindColors.length] : (this.props.segmentColors[i] == undefined || this.props.segmentColors[i] == null || this.props.segmentColors[i] == '') ? "#000000" : this.props.segmentColors[i];
                let meObj = Object.create(null);
                meObj.fill = sectioColorParam;
                meObj.stroke = sectioColorParam;
                meObj.sectionPercent = this.props.segmentPercentage[i];
        
                sections.push(meObj);
            }
        }else{
            sections = this.props.sections;
        }
        
        const margin = { left: 10, right: 10, top: 38, bottom: 20 };

        const width = Math.round(this.props.width - (margin.left + margin.right));
        const height = Math.round(this.props.height - (this.props.height/2));

        const radius = Math.min(this.props.width, this.props.height) / 4;
        const sectionPerc = 1 / segmentsParams / 2;
        const padRad = 0.0;

        let totalPercent = 0.75;
        const chartInset = -25;

        return sections.map((sectionProps, index) => {
            const arcStartRad = this.percentToRad(totalPercent);
            const arcEndRad = arcStartRad + this.percentToRad(sectionProps.sectionPercent ? sectionProps.sectionPercent/2/100 : sectionPerc);
            totalPercent += sectionProps.sectionPercent ? sectionProps.sectionPercent/2/100 : sectionPerc;

            const startPadRad = index === 0 ? 0 : padRad / 2;
            const endPadRad = index === segmentsParams ? 0 : padRad / 2;

            const transform = `translate(${this.props.width / 4}, ${height / 2})`;

            return (
                <SpeedoMeterSegment
                    key={index + '_speedoMeterSegment'}
                    transform={transform}
                    {...sectionProps}
                    width={width}
                    height={height}
                    innerRadius={radius - chartInset - this.props.barWidth}
                    outerRadius={radius - chartInset}
                    startAngle={arcStartRad + startPadRad}
                    endAngle={arcEndRad - endPadRad}
                />);
        });
    };

    render() {
        const needleTransform = () => {
            return `translate(${(this.props.width) / 2}, ${(this.props.height) / 2})`;
        };

        return (
            <div>
                {/* 
                * Draw complete speedmeter guage as svg 
                * @Params width and height
                */}
                <svg width={this.props.width} height={this.props.height} >
                    {
                        this.renderSections()
                    }
                    {/* 
                    * Render Needle component to draw needle
                    * @Params percent, length, radius and needleColor
                    */}
                    <Needle 
                        percent={(this.props.percent-0.5)/100} 
                        length={this.props.needleLength} 
                        radius={this.props.needleRadius} 
                        transform={needleTransform()}
                        needleColor={this.props.needleColor}
                    />
                    {/* 
                    * Render PercentText component to print percentage text
                    * @Params percent and textSize
                    */}
                    <PercentText textSize={this.props.textSize} transform={needleTransform()} percent={this.props.percent}/>
                </svg>
            </div>
        );
    }
}

/*
* Class or Component for displaying Needle based on Percentage value
* @Params percent, length, radius and needleColor
*/
class Needle extends Component {
    static propTypes = {
        percent: PropTypes.number,
        length: PropTypes.number,
        radius: PropTypes.number,
        needleColor: PropTypes.string,
        transform: PropTypes.string,
    };

    percentToDeg = (perc) => {
        return perc * 360;
    };
    
    percentToRad = (perc) => {
        return this.degToRad(this.percentToDeg(perc));
    };

    degToRad = (deg) => {
        return deg * Math.PI / 180;
    };

    getNeedlePath = () => {
        const thetaRad = this.percentToRad(this.props.percent) / 2;

        const centerX = 0;
        const centerY = 0;

        const topX = centerX - this.props.length * Math.cos(thetaRad);
        const topY = centerY - this.props.length * Math.sin(thetaRad);

        const leftX = centerX - this.props.radius * Math.cos(thetaRad - Math.PI / 2);
        const leftY = centerY - this.props.radius * Math.sin(thetaRad - Math.PI / 2);

        const rightX = centerX - this.props.radius * Math.cos(thetaRad + Math.PI / 2);
        const rightY = centerY - this.props.radius * Math.sin(thetaRad + Math.PI / 2);
        return `M ${leftX} ${leftY} L ${topX} ${topY} L ${rightX} ${rightY}`;
    };

    render() {
        const path = this.getNeedlePath();
        return (
            <g transform={this.props.transform}>
                <path className="needle" d={path} style={{fill: this.props.needleColor, stroke: this.props.needleColor}}/>
                <circle className="needle-center" style={{fill: this.props.needleColor, stroke: this.props.needleColor}} cx="0" cy="0" r={this.props.radius}/>
            </g>
        );
    }
}
/*
* Class or Component for displaying Percentage value
* @Params percent and textSize
*/
class PercentText extends Component {
    static propTypes = {
        percent: PropTypes.number,
        textSize: PropTypes.string,
        transform: PropTypes.string
    };

    render() {
        return(
            <g transform={this.props.transform}>
                <text 
                    className="current-value" 
                    textAnchor="middle" 
                    y="25%" 
                    x="5%" 
                    style={{fontSize: this.props.textSize, fontWeight: "300px", fill: "#121212"}}>{this.props.percent}%
                </text>
            </g>
        );
    }
}

/*
* Setting default paramters for speedo meter
*/
SpeedoMeterGuage.defaultProps = {
    width: 120,
    height: 120,
    percent: 50,
    barWidth: 20,
    needleLength: 60,
    needleRadius: 5,
    needleColor: '#464A4F',
    textSize: '20px',
    blindColors:[ "#87871f", "#f8e71c", "#828275", "#5f5fb3" ],  
    colorBlindness:false,  
    sections: [
        { fill: '#d0021b', stroke: '#d0021b', sectionPercent: 33.33 },
        { fill: '#f8e71c', stroke: '#f8e71c', sectionPercent: 33.33 },
        { fill: '#2ecc71', stroke: '#2ecc71', sectionPercent: 33.33 }
    ]
  };
/*
* PropType Validation for speedo meter
*/


export default SpeedoMeterGuage;